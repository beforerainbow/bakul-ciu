package com.example.easynote.dto;

import com.example.easynote.model.User;
import lombok.Data;

@Data
public class DtoUser {
    private Long userId;
    private String first_name;
    private String last_name;
    private String address;

    public DtoUser() {
    }

    public DtoUser(User barkonah) {
        this.userId = barkonah.getId();
        this.first_name = barkonah.getFirstName();
        this.last_name = barkonah.getLastName();
        this.address = barkonah.getAddress();
    }

}
