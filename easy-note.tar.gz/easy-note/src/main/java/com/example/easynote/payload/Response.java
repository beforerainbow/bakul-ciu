package com.example.easynote.payload;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
public class Response{
  private Object data;

  public Response() {}

  public Response(Object data) {
    this.data = data;
  }
}

