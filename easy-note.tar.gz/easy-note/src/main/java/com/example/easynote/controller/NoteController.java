package com.example.easynote.controller;

import com.example.easynote.dto.DtoData;
import com.example.easynote.dto.DtoUser;
import com.example.easynote.dto.NoteDto;
import com.example.easynote.exception.ResourceNotFoundException;
import com.example.easynote.model.Note;
import com.example.easynote.model.User;
import com.example.easynote.payload.Response;
import com.example.easynote.repository.NoteRespository;
import com.example.easynote.repository.UserRepository;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.lang.reflect.Array;
import java.util.*;

@RestController
@RequestMapping("/api")
@Tag(name = "note")
public class NoteController {
    @Autowired
    NoteRespository noteRespository;

    @Autowired
    UserRepository userRepository;

    @GetMapping("/notes")
    public ResponseEntity<?> getAllNotes() {

        List<Note> note = noteRespository.findAll();
        List<Object> rowData = new ArrayList<>();

        for (int i = 0; i < note.size(); i++) {
            Note rowNote = note.get(i);
            Optional<User> user = userRepository.findById(rowNote.getUserId());
            Map<String, Object> gembyus = new HashMap<>();
            gembyus.put("user", user);
            gembyus.put("note", rowNote);

            rowData.add(gembyus);
        }
        return ResponseEntity.ok(new Response(rowData));
    }

    @GetMapping("/notes/dang")
    public ResponseEntity<?> getAll() {

        List<Note> note = noteRespository.findAll();
        List<Object> rowData = new ArrayList<>();

        for (int i = 0; i < note.size(); i++) {
            Note rowNote = note.get(i);
            User user = userRepository.selectUser(rowNote.getUserId());

            DtoUser dtoUser = new DtoUser(user);
            NoteDto dto = new NoteDto(rowNote, dtoUser);

            rowData.add(dto);
        }
        return ResponseEntity.ok(new Response(rowData));
    }


    @PostMapping("/notes/{user_id}")
    public ResponseEntity<?> createNote(@Valid @RequestBody Note note, @PathVariable Long user_id) {
        note.setUserId(user_id);
        return ResponseEntity.ok(new Response(noteRespository.save(note)));
    }

    @GetMapping("/notes/{id}")
    public ResponseEntity<Response> getNotById(@PathVariable(value = "id") Long noteId) {
        final Note note = noteRespository.findById(noteId).orElseThrow(() -> new ResourceNotFoundException("Note", "id", noteId));
        note.setContent("danggoreng");
        return ResponseEntity.ok(new Response(note));
    }

    @PutMapping("/notes/{id}")
    public ResponseEntity<?> updateNote(@PathVariable(value = "id") Long noteId, @Valid @RequestBody Note noteDetails) {
        Note note = noteRespository.findById(noteId).orElseThrow(() -> new ResourceNotFoundException("Note", "id", noteId));
        note.setTitle(noteDetails.getTitle());
        note.setContent(noteDetails.getContent());

        Note updatedNote = noteRespository.save(note);
        return ResponseEntity.ok(updatedNote);
    }

    @DeleteMapping("/notes/{id}")
    public ResponseEntity<?> deleteNote(@PathVariable(value = "id") Long noteId) {
        Note note = noteRespository.findById(noteId).orElseThrow(() -> new ResourceNotFoundException("Note", "id", noteId));
        noteRespository.delete(note);
        return ResponseEntity.ok(new Response("delete data id " + noteId));
    }

    @GetMapping("/myFuckingArray")
    public ResponseEntity<?> uwu() {
        List<String> dewo = new ArrayList<>();
        dewo.add(0, "aku");
        dewo.add(1, "kamu");
        dewo.add(2, "mereka");
        dewo.add(3, "dia");
        dewo.add(4, "engkau");


        ArrayList gedang = new ArrayList(dewo);
        gedang.set(0, "dewo mambu");
        gedang.set(dewo.size() - 1, "mungkin kah ganti");


        Map<String, Object> goreng = new HashMap<>();
        goreng.put("array_last", dewo);
        goreng.put("array_new", gedang);
        return ResponseEntity.ok(goreng);
    }

    @GetMapping("/myFuckingArray/oy")
    public ResponseEntity<?> uwahahu() {
        List<String> dewo = new ArrayList<>();
        dewo.add("bejo");
        dewo.add("barkonah");
        dewo.add("sulastri");

        List<String> dewo1 = new ArrayList<>();
        dewo1.add("bendera");
        dewo1.add("kotak");
        dewo1.add("bulet");

        ArrayList<String> dewo2 = new ArrayList<>();
        dewo2.add("segitiga");
        dewo2.add("aspal");
        dewo2.add("air");

//        ArrayList tambah = new ArrayList(dewo);
//        tambah.add(3, "udara");
//
//        ArrayList kurang = new ArrayList(dewo1);
//        kurang.add(2, dewo2);

        ArrayList<List<String>> dewo3 = new ArrayList<>();
        dewo3.add(dewo);
        dewo3.add(dewo1,;
        dewo3.add(dewo2);
//        dewo3.add(kurang);

        Map<String, Object> goreng = new HashMap<>();
        goreng.put("Array Lama", dewo3);

        return ResponseEntity.ok(goreng);
    }

}
