package com.example.easynote.dto;

import lombok.Data;

@Data
public class DtoData {
    private Object user;
    private Object note;

    public DtoData() {
    }

    public DtoData(Object user) {
        this.user = user;
    }
}
