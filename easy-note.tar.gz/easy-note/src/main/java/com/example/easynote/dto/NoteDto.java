package com.example.easynote.dto;

import com.example.easynote.model.Note;
import lombok.Data;

@Data
public class NoteDto {
  private Long id;
  private String title;
  private String content;
  private DtoUser userBarkonah;

  public NoteDto() {
  }

  public NoteDto(Note note, DtoUser dtoUser) {
    this.id = note.getId();
    this.title = note.getTitle();
    this.content = note.getContent();
    this.userBarkonah = dtoUser;
  }
}

