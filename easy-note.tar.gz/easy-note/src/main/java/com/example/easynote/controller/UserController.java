package com.example.easynote.controller;

import com.example.easynote.model.Note;
import com.example.easynote.model.User;
import com.example.easynote.payload.Response;
import com.example.easynote.repository.UserRepository;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/users")
@Tag(name = "User")
public class UserController {

    @Autowired
    UserRepository userRepository;

    @PostMapping
    public User createUser(@Valid @RequestBody User user) {
        return userRepository.save(user);
    }

    @GetMapping
    public ResponseEntity<?> getDatauser() {
        return ResponseEntity.ok(new Response(userRepository.findAll()));
    }
}
